import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt


# PAGE CONFIGURATION

st.set_page_config(
    page_title="Diabetes Data Analysis",
    page_icon="🏥",
    layout="wide"
)


# TITLE

st.title("🏥 Diabetes Data Analysis Dashboard")

st.write(
    "An Exploratory Data Analysis project using "
    "Python, Pandas, Matplotlib, and Streamlit."
)



# LOAD DATA

url = "https://raw.githubusercontent.com/jbrownlee/Datasets/master/pima-indians-diabetes.data.csv"

columns = [
    "Pregnancies",
    "Glucose",
    "BloodPressure",
    "SkinThickness",
    "Insulin",
    "BMI",
    "DiabetesPedigreeFunction",
    "Age",
    "Outcome"
]

df = pd.read_csv(url, names=columns)


# DATA CLEANING

zero_columns = [
    "Glucose",
    "BloodPressure",
    "SkinThickness",
    "Insulin",
    "BMI"
]

for column in zero_columns:
    df[column] = df[column].replace(0, pd.NA)
    df[column] = pd.to_numeric(df[column])
    df[column] = df[column].fillna(df[column].median())


# SIDEBAR FILTER

st.sidebar.header("Dashboard Filters")

outcome_option = st.sidebar.selectbox(
    "Select Diabetes Outcome",
    ["All", "Diabetes", "No Diabetes"]
)


# FILTER DATA

if outcome_option == "Diabetes":

    filtered_df = df[df["Outcome"] == 1]

elif outcome_option == "No Diabetes":

    filtered_df = df[df["Outcome"] == 0]

else:

    filtered_df = df.copy()


# DATASET OVERVIEW

st.header("📋 Dataset Overview")

col1, col2, col3, col4 = st.columns(4)

col1.metric(
    "Total Patients",
    len(filtered_df)
)

col2.metric(
    "Average Age",
    round(filtered_df["Age"].mean(), 1)
)

col3.metric(
    "Average BMI",
    round(filtered_df["BMI"].mean(), 1)
)

col4.metric(
    "Average Glucose",
    round(filtered_df["Glucose"].mean(), 1)
)


# VIEW DATASET

with st.expander("View Dataset"):
    st.dataframe(filtered_df)


# GRAPH 1: DIABETES OUTCOME

st.header("🩺 Diabetes Outcome")

outcome_counts = df["Outcome"].value_counts()

fig1, ax1 = plt.subplots()

ax1.bar(
    ["No Diabetes", "Diabetes"],
    [
        outcome_counts.get(0, 0),
        outcome_counts.get(1, 0)
    ]
)

ax1.set_title("Diabetes Outcome Distribution")
ax1.set_xlabel("Outcome")
ax1.set_ylabel("Number of Patients")

st.pyplot(fig1)


# GRAPH 2: AGE DISTRIBUTION

st.header("👥 Age Distribution")

fig2, ax2 = plt.subplots()

ax2.hist(
    filtered_df["Age"],
    bins=10
)

ax2.set_title("Age Distribution")
ax2.set_xlabel("Age")
ax2.set_ylabel("Number of Patients")

st.pyplot(fig2)


# GRAPH 3: BMI DISTRIBUTION

st.header("⚖️ BMI Distribution")

fig3, ax3 = plt.subplots()

ax3.hist(
    filtered_df["BMI"],
    bins=10
)

ax3.set_title("BMI Distribution")
ax3.set_xlabel("BMI")
ax3.set_ylabel("Frequency")

st.pyplot(fig3)


# GRAPH 4: GLUCOSE VS OUTCOME

st.header("🔬 Glucose vs Diabetes Outcome")

fig4, ax4 = plt.subplots()

ax4.scatter(
    filtered_df["Glucose"],
    filtered_df["Outcome"]
)

ax4.set_title("Glucose vs Diabetes Outcome")
ax4.set_xlabel("Glucose Level")
ax4.set_ylabel("Diabetes Outcome")

st.pyplot(fig4)


# GRAPH 5: AVERAGE GLUCOSE

st.header("📊 Average Glucose by Diabetes Outcome")

average_glucose = df.groupby("Outcome")["Glucose"].mean()

fig5, ax5 = plt.subplots()

ax5.bar(
    ["No Diabetes", "Diabetes"],
    [
        average_glucose.get(0, 0),
        average_glucose.get(1, 0)
    ]
)

ax5.set_title("Average Glucose by Outcome")
ax5.set_xlabel("Outcome")
ax5.set_ylabel("Average Glucose")

st.pyplot(fig5)


# GRAPH 6: BMI VS OUTCOME

st.header("⚖️ BMI vs Diabetes Outcome")

fig6, ax6 = plt.subplots()

ax6.boxplot(
    [
        df[df["Outcome"] == 0]["BMI"],
        df[df["Outcome"] == 1]["BMI"]
    ],
    tick_labels=["No Diabetes", "Diabetes"]
)

ax6.set_title("BMI Comparison by Diabetes Outcome")
ax6.set_xlabel("Outcome")
ax6.set_ylabel("BMI")

st.pyplot(fig6)


# CORRELATION

st.header("🔗 Correlation Analysis")

correlation_matrix = df.corr(numeric_only=True)

fig7, ax7 = plt.subplots(figsize=(10, 7))

image = ax7.imshow(
    correlation_matrix,
    interpolation="nearest"
)

ax7.set_xticks(range(len(correlation_matrix.columns)))
ax7.set_yticks(range(len(correlation_matrix.columns)))

ax7.set_xticklabels(
    correlation_matrix.columns,
    rotation=90
)

ax7.set_yticklabels(
    correlation_matrix.columns
)

ax7.set_title("Correlation Matrix")

# Add correlation values inside the graph

for i in range(len(correlation_matrix.columns)):
    for j in range(len(correlation_matrix.columns)):

        ax7.text(
            j,
            i,
            f"{correlation_matrix.iloc[i, j]:.2f}",
            ha="center",
            va="center"
        )

fig7.colorbar(image)

st.pyplot(fig7)


# GLUCOSE CORRELATION

glucose_correlation = df["Glucose"].corr(
    df["Outcome"]
)

st.subheader(
    "Correlation between Glucose and Diabetes Outcome"
)

st.write(
    f"Correlation: **{glucose_correlation:.4f}**"
)


# OUTLIER DETECTION

st.header("📦 Glucose Outlier Detection")

fig8, ax8 = plt.subplots()

ax8.boxplot(
    filtered_df["Glucose"]
)

ax8.set_title("Glucose Box Plot")
ax8.set_ylabel("Glucose")

st.pyplot(fig8)


# IQR CALCULATION

Q1 = filtered_df["Glucose"].quantile(0.25)

Q3 = filtered_df["Glucose"].quantile(0.75)

IQR = Q3 - Q1

lower_limit = Q1 - 1.5 * IQR

upper_limit = Q3 + 1.5 * IQR


outliers = filtered_df[
    (filtered_df["Glucose"] < lower_limit)
    |
    (filtered_df["Glucose"] > upper_limit)
]


st.subheader("Potential Glucose Outliers")

col1, col2 = st.columns(2)

col1.metric(
    "Lower Limit",
    round(lower_limit, 2)
)

col2.metric(
    "Upper Limit",
    round(upper_limit, 2)
)


if len(outliers) > 0:

    st.warning(
        f"{len(outliers)} potential outlier(s) detected."
    )

    st.dataframe(outliers)

else:

    st.success(
        "No potential glucose outliers detected."
    )


# STATISTICAL SUMMARY

st.header("📈 Statistical Summary")

st.dataframe(
    df.describe()
)


# KEY INSIGHTS

st.header("🎯 Key Insights")

average_glucose_no_diabetes = df[
    df["Outcome"] == 0
]["Glucose"].mean()

average_glucose_diabetes = df[
    df["Outcome"] == 1
]["Glucose"].mean()

average_bmi_no_diabetes = df[
    df["Outcome"] == 0
]["BMI"].mean()

average_bmi_diabetes = df[
    df["Outcome"] == 1
]["BMI"].mean()


st.write(
    f"• Average glucose for diabetes group: "
    f"**{average_glucose_diabetes:.2f}**"
)

st.write(
    f"• Average glucose for no-diabetes group: "
    f"**{average_glucose_no_diabetes:.2f}**"
)

st.write(
    f"• Average BMI for diabetes group: "
    f"**{average_bmi_diabetes:.2f}**"
)

st.write(
    f"• Average BMI for no-diabetes group: "
    f"**{average_bmi_no_diabetes:.2f}**"
)

st.write(
    f"• Glucose-Outcome correlation: "
    f"**{glucose_correlation:.4f}**"
)

st.write(
    f"• Total patient records: **{len(df)}**"
)


# FOOTER

st.markdown("---")

st.write(
    "Healthcare Data Analysis Project | "
    "Python • Pandas • Matplotlib • Streamlit"
)